document.getElementById('ipForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const ip = document.getElementById('ipInput').value;
    const apiUrl = `https://ipapi.co/${ip}/json/`;
    
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            displayIpInfo(data);
            document.getElementById('mapBtn').style.display = 'inline-block';
        })
        .catch(error => console.error('Error fetching IP info:', error));
});

function displayIpInfo(data) {
    const ipInfoDiv = document.getElementById('ipInfo');
    ipInfoDiv.innerHTML = `
        <p><strong>IP:</strong> ${data.ip}</p>
        <p><strong>City:</strong> ${data.city}</p>
        <p><strong>Region:</strong> ${data.region}</p>
        <p><strong>Country:</strong> ${data.country_name}</p>
        <p><strong>Latitude:</strong> ${data.latitude}</p>
        <p><strong>Longitude:</strong> ${data.longitude}</p>
        <p><strong>Provider:</strong> ${data.org}</p>
    `;
    
    const mapBtn = document.getElementById('mapBtn');
    mapBtn.onclick = () => {
        window.open(`https://www.google.com/maps?q=${data.latitude},${data.longitude}`, '_blank');
    };
}
